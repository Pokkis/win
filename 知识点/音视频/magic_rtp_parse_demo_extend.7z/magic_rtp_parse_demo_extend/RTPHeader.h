#pragma once

#pragma pack(push,1) //设定为1字节对齐
struct RtpHdr
{
//#if __BYTE_ORDER == __LITTLE_ENDIAN
		uint8_t cc : 4,  	// CSRC count
		x : 1,   			// header extend
		p : 1,   			// padding flag
		version : 2;		// version
		uint8_t pt : 7,		// payload type
		m : 1;				// mark bit
//#elif __BYTE_ORDER == __BIG_ENDIAN
//#error "unsupported big-endian"
//#else
//#error "Please fix <endian.h>"
//#endif
	uint16_t seq;				// sequence number;
	uint32_t ts;				// timestamp
	uint32_t ssrc;				// sync source
} ;

struct FUIndicator
{
	uint8_t ftype : 5,  	// 分包设为28
		nri : 2,   			// NALU的重要性标示
		f : 1;   			// 0
};
struct FUHeader
{
	uint8_t ftype : 5,   // 与NALU的Header的type一致  抓包看都是1
		r : 1,   			// 设为0
		e : 1,   			// 标示结束 1为分包结束  end
		s : 1;   			// 标示开始 1为分包开始  start
};
struct RtpTcpHdr
{
	int8_t	dollar;
	int8_t	channel;
	int16_t	len;
} ;

struct rtcphdr
{
#if __BYTE_ORDER == __LITTLE_ENDIAN
	uint16_t rc : 5;
	uint16_t p : 1;
	uint16_t version : 2;
	uint16_t pt : 8;
#elif __BYTE_ORDER == __BIG_ENDIAN
	uint16_t version : 2;
	uint16_t p : 1;
	uint16_t rc : 5;
	uint16_t pt : 8;
#else
#error "Please fix <bits/endian.h>"
#endif
	uint16_t length;
};


#pragma pack(pop) //恢复对齐状态
