#include <dirent.h> 
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <string.h>

#include <stdio.h>
#include <unistd.h>
#include <dirent.h> 
#include <sys/types.h> 
#include <sys/stat.h> 

#include "RTPHeader.h"


using namespace std;


#define H264FRAME_PACKETLEN_DEF				1024*512
#define PARSE_BUF_MAX_LEN					4096


#define MLOG_PRINTF 1
const static char *log_level_str[] = {"D", "I", "W", "E", "F"};
#define mlog(log_level, log_fmt, log_arg...) \
    do{ \
        if (MLOG_PRINTF) { \
            printf("file: %s:%d, %s:", __FILE__, __LINE__, log_level_str[log_level]); \
            printf(log_fmt, ##log_arg); \
        } \
    } while (0)

enum MLOG_LEVEL{M_DEBUG, M_INFO, M_WARNING, M_ERROR, M_FATAL};

/*
*  RTP解析
* @author [ymj]
* @version [0.0.1, 2019-11-10]
* add rtp on udp by waylon on 2020-11-30
*/

static int create_dir(const char *path)
{
    char dir_name[256];
    strcpy(dir_name, path);
    int i;
    int len = strlen(dir_name);
    if(dir_name[len-1] != '/') {
        strcat(dir_name, "/");
    }
    len = strlen(dir_name);

    for(i = 1; i < len; i++) {
        if(dir_name[i]=='/') {
            dir_name[i] = 0;
            if(access(dir_name, F_OK) != 0) {
                if(mkdir(dir_name, 0755) == -1)  {
                    mlog(M_ERROR, "mkdir error, dir: %s \n", dir_name);
                    return -1;
                }
            }
            dir_name[i] =  '/';
        }
    }

    return 0;
}

/* return front bytes */
static int binary_find (int whichOne, uint8_t *buf, int buflen, uint8_t *sub, int sublen)
{
    if(whichOne <= 0 || buf == NULL || buflen <= 0 || sub == NULL || sublen <= 0) {
		mlog(M_ERROR, "%s invalid argument, whilhOne: %d, buf: %p, buflen: %d, sub: %p, sublen: %d \n",
				__FUNCTION__, whichOne, buf, buflen, sub, sublen);
        return -1;
    }
    
    int blen = 0;
    int slen = 0;
    uint8_t *bp, *sp;
    while (blen < buflen) {
        slen = 0;
        bp = buf;
        sp = sub;
        while (*bp++ == *sp++) {        
            slen++;
            if(slen >= sublen) {
				if (--whichOne > 0) {
					break;
				} else {
					return blen;
				}     
            }
        }
        buf++;
        blen++;
    }
    return -1;
}

int rtp_on_tcp(string strInputfile, string stroutputfile, string stroutputtxt)
{
	//打开所需要的文件句柄
    //输出文件
    ofstream oFile(stroutputfile.c_str(), ios::out | ios::trunc);
    if (!oFile) {
        mlog(M_ERROR, "[%s] abnormal!!! \n", stroutputfile.c_str());
        return -1;
    }
    //输出文件
    ofstream oFileTxt(stroutputtxt.c_str(), ios::out | ios::trunc);
    if (!oFileTxt) {
        mlog(M_ERROR, "[%s] abnormal!!! \n", stroutputtxt.c_str());
        return -1;
    }
    //输入文件
    ifstream inFile( strInputfile.c_str(), ios::in);
    if (!inFile) {
        mlog(M_ERROR, "[%s] abnormal!!! \n", strInputfile.c_str());
        return -1;
    }

    //解析
    unsigned char * buf = new unsigned char [H264FRAME_PACKETLEN_DEF];
	while (true) {
		unsigned short nRecvHeader;
		//读取长度
		inFile.read((char*)&nRecvHeader ,2);
		if(inFile.eof()) {
			break;
		}
		nRecvHeader = ((nRecvHeader & 0x00FF) << 8) | ((nRecvHeader & 0xFF00) >> 8);
		memset(buf , 0x00, H264FRAME_PACKETLEN_DEF);
		if(nRecvHeader > 0) {
			memset(buf,0x00 ,H264FRAME_PACKETLEN_DEF);
			inFile.read((char*) buf, nRecvHeader);
			unsigned char* pData = buf;

			RtpHdr* pRTPHeader = (RtpHdr*)pData;
			int nDataLen = nRecvHeader - sizeof(RtpHdr);//所有载荷 长度，包括扩展字段
			pRTPHeader->seq = ((pRTPHeader->seq & 0x00FF) << 8) |  ((pRTPHeader->seq >> 8)) ;

			pRTPHeader->ts = ((pRTPHeader->ts & 0x000000FF) << 24) |  ((pRTPHeader->ts & 0x0000FF00) << 8) |  ((pRTPHeader->ts & 0x00FF0000) >> 8) | ((pRTPHeader->ts & 0xFF000000) >> 24) ;

			pRTPHeader->ssrc = ((pRTPHeader->ssrc & 0x000000FF) << 24) |  ((pRTPHeader->ssrc & 0x0000FF00) << 8) |  ((pRTPHeader->ssrc & 0x00FF0000) >> 8) | ((pRTPHeader->ssrc & 0xFF000000) >> 24) ;
			pData += sizeof(RtpHdr);//有效载荷开始
			unsigned char* pPaddingData = nullptr;
			int nPaddingDataLen = 0;
			int nSec;
			if (pRTPHeader->p == 1) {
				nPaddingDataLen = (pData[nDataLen - 1] & 0xFF )- 1 ;
				if (nPaddingDataLen < 0 ) {
					mlog(M_ERROR, "Padding DataLen err: %d \n", nPaddingDataLen);
				}
				pPaddingData = pData + nDataLen - nPaddingDataLen - 1;
				nDataLen -= nPaddingDataLen + 1;

				void* pTmp =  pPaddingData;
				unsigned int * pTmp2 = (unsigned int*)pTmp;
				nSec = ((*pTmp2& 0x000000FF) << 24) |  ((*pTmp2 & 0x0000FF00) << 8) |  (( *pTmp2 & 0x00FF0000) >> 8) | (( *pTmp2 & 0xFF000000) >> 24) ;
			}

			 oFileTxt <<" RTPHeader->seq: " << pRTPHeader->seq <<" RTPHeader->ts: " << pRTPHeader->ts
					<<" RTPHeader->ssrc: " << pRTPHeader->ssrc << " Rtp data:" << nDataLen
					<< " Padding time:" << nSec << " Padding len: "  << nPaddingDataLen << endl ;
			oFile.write((char*)pData, nDataLen);
			oFileTxt.flush();
		}else
		{
			break;
		}
	}
	
	delete buf;

	//关闭文件句柄
	oFileTxt.close();
	inFile.close();
	oFile.close();

	return 0;
}

int rtp_on_udp(string strInputfile, string stroutputfile, string stroutputtxt)
{
	//打开所需要的文件句柄
    //输出文件
    ofstream oFile(stroutputfile.c_str(), ios::out | ios::trunc);
    if (!oFile) {
        mlog(M_ERROR, "[%s] abnormal!!! \n", stroutputfile.c_str());
        return -1;
    }
    //输出文件
    ofstream oFileTxt(stroutputtxt.c_str(), ios::out | ios::trunc);
    if (!oFileTxt) {
        mlog(M_ERROR, "[%s] abnormal!!! \n", stroutputtxt.c_str());
        return -1;
    }
    //输入文件
    ifstream inFile(strInputfile.c_str(), ios::in);
    if (!inFile) {
        mlog(M_ERROR, "[%s] abnormal!!! \n", strInputfile.c_str());
        return -1;
    }

    //解析
    unsigned char *parseBuf = new unsigned char [PARSE_BUF_MAX_LEN];
	memset(parseBuf , 0x00, PARSE_BUF_MAX_LEN);
	int parseBufLen = 0;
    unsigned char *buf = new unsigned char [H264FRAME_PACKETLEN_DEF];
	/* ts and ssrc */
	uint8_t rtpHeadCheckData[4] = {0};
	uint8_t lastRtpHeadCheckData[4] = {0};
	uint8_t tmpBuf[32] = {0};
	int tmpBufLen = 0;
	int rtpHeadCheckDataLen = sizeof(rtpHeadCheckData);
	int offsetCheckData = 8;
	int diffCnt = 0;
	int lastRtpSeqNum = 0;
	int rtpSeqNum = 0;
	int parseLen = 0;
	
	/* read rtp header */
	if (parseBufLen < PARSE_BUF_MAX_LEN) {
		inFile.read((char*)parseBuf + parseBufLen, sizeof(RtpHdr));
		if(inFile.eof()) {
			mlog(M_ERROR, "inFile read invalde data \n");
			return -1;
		}
		parseBufLen += inFile.gcount();
	}

	if(parseBufLen > 0) {
		RtpHdr *rtpHeaderPtr = (RtpHdr *)parseBuf;

		/* save and check rtp ssrc info */
		memcpy(rtpHeadCheckData, parseBuf + offsetCheckData, rtpHeadCheckDataLen);
		if (memcmp(lastRtpHeadCheckData, rtpHeadCheckData, rtpHeadCheckDataLen) != 0) {
			diffCnt++;
			mlog(M_WARNING, "diffCnt: %d \n", diffCnt);

			int i;
			tmpBufLen = 0;
			for (i = 0; i < rtpHeadCheckDataLen; i++) {
				tmpBufLen += snprintf((char *)(tmpBuf + tmpBufLen), 32 - tmpBufLen, "%02x  ", rtpHeadCheckData[i]);
			}
			mlog(M_WARNING, "rtpHeadCheckData: %s \n", tmpBuf);

			tmpBufLen = 0;
			for (i = 0; i < rtpHeadCheckDataLen; i++) {
				tmpBufLen += snprintf((char *)(tmpBuf + tmpBufLen), 32 - tmpBufLen, "%02x  ", lastRtpHeadCheckData[i]);
			}
			mlog(M_WARNING, "lastRtpHeadCheckData: %s \n", tmpBuf);

			memcpy(lastRtpHeadCheckData, rtpHeadCheckData, rtpHeadCheckDataLen);
		}

		/* save rtp seq info */
		rtpSeqNum = ((rtpHeaderPtr->seq & 0x00FF) << 8) | ((rtpHeaderPtr->seq >> 8));
		mlog(M_DEBUG, "rtp seq num, last: %d, cur: %d \n", lastRtpSeqNum, rtpSeqNum);
	}

	/* read data */
	while (true) {
		unsigned char *pData = NULL;
		int nDataLen = 0;
		int checkIndex = -1;
		int whichOne = 1;
		RtpHdr *pRTPHeader =  NULL;

		if (parseBufLen < PARSE_BUF_MAX_LEN) {
			inFile.read((char*)parseBuf + parseBufLen, PARSE_BUF_MAX_LEN - parseBufLen);
			if(inFile.eof()) {
				break;
			}
			parseBufLen += inFile.gcount();
		}

		if(parseBufLen > 0) {
			while (true) {
				if (parseBufLen < parseLen + sizeof(RtpHdr)) {
					mlog(M_ERROR, "data error, parseBufLen--parseLen, %d--%d, next read data \n", parseBufLen, parseLen);
					memcpy(parseBuf, parseBuf + parseLen, parseBufLen - parseLen);
					parseBufLen -= parseLen;
					parseLen = 0;
					break;
				}

				if (parseBufLen == parseLen + sizeof(RtpHdr)) {
					mlog(M_WARNING, "data lack, parseBufLen--parseLen, %d--%d, next read data \n", parseBufLen, parseLen);
					memcpy(parseBuf, parseBuf + parseLen, parseBufLen - parseLen);
					parseBufLen -= parseLen;
					parseLen = 0;
					break;
				}

				pData = parseBuf + parseLen;
				pRTPHeader = (RtpHdr *)pData;

				/* save and check rtp ts ssrc info */
				memcpy(rtpHeadCheckData, pData + offsetCheckData, rtpHeadCheckDataLen);
				if (memcmp(lastRtpHeadCheckData, rtpHeadCheckData, rtpHeadCheckDataLen) != 0) {
					diffCnt++;
					mlog(M_WARNING, "diffCnt: %d \n", diffCnt);
					int i;
					mlog(M_WARNING, "rtpHeadCheckData: \n");
					for (i = 0; i < rtpHeadCheckDataLen; i++) {
						printf("%02x  ", rtpHeadCheckData[i]);
					}
					
					mlog(M_WARNING, "lastRtpHeadCheckData: \n");
					for (i = 0; i < rtpHeadCheckDataLen; i++) {
						printf("%02x  ", lastRtpHeadCheckData[i]);
					}
					cout << endl << endl;
					memcpy(lastRtpHeadCheckData, rtpHeadCheckData, rtpHeadCheckDataLen);
				}

				/* check next rtp heaer, calc rtp pkt len */
				checkIndex = binary_find(whichOne, pData + sizeof(RtpHdr), parseBufLen - parseLen - sizeof(RtpHdr), rtpHeadCheckData, rtpHeadCheckDataLen);
				if (checkIndex < 0) {
					/* not find and save remaining data */
					memcpy(parseBuf, parseBuf + parseLen, parseBufLen - parseLen);
					parseBufLen -= parseLen;
					parseLen = 0;
					//mlog(M_DEBUG, "find nothing, continue read data, remain date len: %d \n", parseBufLen);
					break;
				}

				/* save and check rtp seq info */
				rtpSeqNum = ((pRTPHeader->seq & 0x00FF) << 8) | ((pRTPHeader->seq >> 8));
				if (lastRtpSeqNum != 0 && lastRtpSeqNum != rtpSeqNum - 1) {
					mlog(M_WARNING, "skip rtp seq num, last: %d, cur: %d \n", lastRtpSeqNum, rtpSeqNum);
					whichOne++;
					continue;
				}
				lastRtpSeqNum = rtpSeqNum;
				whichOne = 1;
				
				/* payload len */
				nDataLen = checkIndex - offsetCheckData;
				pData += sizeof(RtpHdr);
				
				unsigned char* pPaddingData = nullptr;
				int nPaddingDataLen = 0;
				int nSec;
				if (pRTPHeader->p == 1) {
					nPaddingDataLen = (pData[nDataLen - 1] & 0xFF ) - 1 ;
					if(nPaddingDataLen < 0 ) {
						mlog(M_ERROR, "Padding DataLen err: %d \n", nPaddingDataLen);
					}
					pPaddingData = pData + nDataLen - nPaddingDataLen - 1;
					nDataLen -= nPaddingDataLen + 1;

					void* pTmp =  pPaddingData;
					unsigned int * pTmp2 = (unsigned int*)pTmp;
					nSec = ((*pTmp2& 0x000000FF) << 24) | 
							((*pTmp2 & 0x0000FF00) << 8) | 
							(( *pTmp2 & 0x00FF0000) >> 8) | 
							(( *pTmp2 & 0xFF000000) >> 24) ;

					parseLen += sizeof(RtpHdr) + nDataLen + nPaddingDataLen + 1;
				} else {
					parseLen += sizeof(RtpHdr) + nDataLen;
				}

				RtpHdr rtpHeaderInfo =  {0};
				rtpHeaderInfo.seq = ((pRTPHeader->seq & 0x00FF) << 8) | ((pRTPHeader->seq >> 8));
				rtpHeaderInfo.ts = ((pRTPHeader->ts & 0x000000FF) << 24) |
						((pRTPHeader->ts & 0x0000FF00) << 8) | 
						((pRTPHeader->ts & 0x00FF0000) >> 8) | 
						((pRTPHeader->ts & 0xFF000000) >> 24) ;
				rtpHeaderInfo.ssrc = ((pRTPHeader->ssrc & 0x000000FF) << 24) | 
						((pRTPHeader->ssrc & 0x0000FF00) << 8) | 
						((pRTPHeader->ssrc & 0x00FF0000) >> 8) | 
						((pRTPHeader->ssrc & 0xFF000000) >> 24) ;

				oFileTxt <<"rtp header info, seq: " << rtpHeaderInfo.seq <<" ts: " << rtpHeaderInfo.ts
						<<" ssrc: " << rtpHeaderInfo.ssrc << " Rtp data:" << nDataLen
						<< " Padding time:" << nSec << " Padding len: "  << nPaddingDataLen << endl ;

				oFile.write((char*)pData, nDataLen);
				oFileTxt.flush();
			}
		} else {
			break;
		}
	}

	delete buf;
	delete parseBuf;

	//关闭文件句柄
	oFileTxt.close();
	inFile.close();
	oFile.close();

	return 0;
}

void usage(const char *app)
{
	cout <<"Sample param:" << endl;
	cout << string(app) << " -t -i input.rtp "<< endl;
	cout << string(app) << " -u -i input.rtp "<< endl;
}

int main(int argc, char *argv[]) {
	int ret;
    std::string strInputfile;
    std::string strInputfileName;
    std::string stroutputfile ="1.avi";
    std::string stroutputtxt ="1.txt";
	/* 0 rtp on tcp, 1 rtp on udp */
	uint8_t rtp_on_base = -1;
//参数获取
    for (size_t i = 0; i < argc; i++)
    {
        if (strcmp(argv[i], "-t") == 0)
		{
			rtp_on_base = 0;
		}

        if (strcmp(argv[i], "-u") == 0)
		{
			rtp_on_base = 1;
		}	

        if (strcmp(argv[i], "-i") == 0)
        {
            if (i+1 < argc)
            {
                strInputfile =argv[++i];
            }
        }
    }

	if(strInputfile.size() <= 0 )
    {
        mlog(M_ERROR, "input file  no find \n");
		usage(argv[0]);
        getchar();
        exit(1);
    }

	strInputfileName = strInputfile.substr(strInputfile.find_last_of('/')+1);
	ret = create_dir("../outputdir/");
	if (ret != 0) {
		mlog(M_ERROR, "create output ps data dir ../outputdir/ failed \n");
		exit(1);
	}
	
	stroutputfile = "../outputdir/" + strInputfileName + ".avi";
	stroutputtxt = "../outputdir/" + strInputfileName + ".txt";

	if (rtp_on_base == 0) {
		mlog(M_DEBUG, "======== rtp on tcp ======== \n");
		ret = rtp_on_tcp(strInputfile, stroutputfile, stroutputtxt);	
		if (ret != 0) {
			mlog(M_ERROR, "rtp_on_tcp return error. \n");
			exit(1);
		}
	} else if (rtp_on_base == 1) {
		mlog(M_DEBUG, "======== rtp on udp ======== \n");
		ret = rtp_on_udp(strInputfile, stroutputfile, stroutputtxt);	
		if (ret != 0) {
			mlog(M_ERROR, "rtp_on_udp return error. \n");
			exit(1);
		}
	} else {	
		mlog(M_ERROR, "rtp on base, invalid arguments: ");
		usage(argv[0]);
        getchar();
        exit(1);
	}
	
	//输出信息
	mlog(M_DEBUG, "file data to: %s \n", stroutputfile.c_str());
	mlog(M_DEBUG, "file txt to: %s \n", stroutputtxt.c_str());
	mlog(M_DEBUG, "parse finish \n");

    return 0;
}
